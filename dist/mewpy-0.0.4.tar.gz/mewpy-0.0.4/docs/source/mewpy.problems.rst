mewpy.problems package
======================

Submodules
----------

mewpy.problems.gecko module
---------------------------

.. automodule:: mewpy.problems.gecko
   :members:
   :undoc-members:
   :show-inheritance:

mewpy.problems.genes module
---------------------------

.. automodule:: mewpy.problems.genes
   :members:
   :undoc-members:
   :show-inheritance:

mewpy.problems.kinetic module
-----------------------------

.. automodule:: mewpy.problems.kinetic
   :members:
   :undoc-members:
   :show-inheritance:

mewpy.problems.problem module
-----------------------------

.. automodule:: mewpy.problems.problem
   :members:
   :undoc-members:
   :show-inheritance:

mewpy.problems.reactions module
-------------------------------

.. automodule:: mewpy.problems.reactions
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: mewpy.problems
   :members:
   :undoc-members:
   :show-inheritance:
