from .tabular import read_tabular_regulatory_model, read_tabular_aliases
from .bnet import read_bnet_file