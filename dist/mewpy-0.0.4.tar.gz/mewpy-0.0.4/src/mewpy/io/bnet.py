import os
import pandas as pd

def read_bnet_file(file_or_filepath):

    pass