mewpy
======

Metabolic Engineering Workbench 
The Python framework under development will allow the strain design of single and microbial community cultures.
This documents presents a brief description of the framework and the main options taken during the development.

Documentation
~~~~~~~~~~~~~

For documentation and API please check:


Instalation
~~~~~~~~~~~


Credits and License
~~~~~~~~~~~~~~~~~~~

Developed at:
-  Centre of Biological Engineering, University of Minho (2019-)

